# Description

The resource is used to initialize, format and mount the partition as a drive letter.
